"""Qurrium Quam-Libs Crossroads - The Converter Between Qurrium and Quam-Libs"""

from .version import __version__, version_info
